#CRITICAL_DEPENDENCIES = ['blender','c4d']
__revision__ = '01'
#__all__ = ["epmvAdaptor","comput_util"]
