#
# copyright_notice
#

"""smap wrappers
"""

__all__ = (
    )

from opengltk.extent import smaplib, utillib
